*AUTOMATED KIDNEY CANCER DETECTION IN NON-CONTRAST COMPUTED TOMOGRAPHY REQUIRES A 3D APPROACH*

used this link to go through python packaging: https://www.linode.com/docs/guides/how-to-create-a-private-python-package-repository/